import 'package:flutter/material.dart';
import 'package:at1/screens/home.dart';

void main() {
  runApp(const MaterialApp(
    home: HomeScreen(),
    debugShowCheckedModeBanner: false,
  ));
}

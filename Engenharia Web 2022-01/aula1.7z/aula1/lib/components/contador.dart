import 'package:flutter/material.dart';

class ContadorComponents extends StatelessWidget {
  const ContadorComponents({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      width: double.infinity,
      color: Colors.grey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "0",
            style: TextStyle(fontSize: 125),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                onPressed: () {},
                icon: Icon(Icons.exposure_minus_1),
                label: Text("Subtrair"),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: Icon(Icons.exposure_plus_1),
                label: Text("Adicionar"),
              ),
            ],
          )
        ],
      ),
    );
  }
}
